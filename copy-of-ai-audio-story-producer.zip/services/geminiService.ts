import { GoogleGenAI, Type } from "@google/genai";
import type { DramatizedScript, Scene, Dialogue, Narration, SceneElement } from '../types';
import { stitchAudioBuffers, decode, decodeAudioData, bufferToWave, mixAudioBuffers, applyFade } from "../utils/audio";
import { BACKGROUND_MUSIC_TRACKS } from "../constants";

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}
const ai = new GoogleGenAI({ apiKey: API_KEY });

interface AudioOptions {
    musicTrackKey: string;
    musicVolume: number;
    generateSfx: boolean;
}

export const analyzeScript = async (text: string): Promise<DramatizedScript> => {
    const model = 'gemini-2.5-pro';
    
    const response = await ai.models.generateContent({
        model,
        contents: `Analyze the following text and transform it into a dramatized script format.
        1.  Identify all distinct characters, including a "Narrator" for descriptive parts.
        2.  Break the story into logical scenes, providing a brief setting description for each.
        3.  For each scene, break down the content into an ordered sequence of elements: dialogue, narration, or sound_cue.
        4.  Dialogue should be assigned to a character.
        5.  Narration should be assigned to the "Narrator".
        6.  Add expressive emotional cues in brackets, like [happily] or [angrily], within the content to guide the tone.
        7.  Invent and insert sound_cue elements where appropriate to enhance immersion. Describe the sound clearly.
        8.  Return ONLY the JSON object, with no markdown formatting.
        
        TEXT TO ANALYZE:
        ---
        ${text}
        ---
        `,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    characters: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                        description: 'List of all character names, excluding Narrator.'
                    },
                    scenes: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                setting: { type: Type.STRING, description: 'A brief description of the scene setting.' },
                                elements: {
                                    type: Type.ARRAY,
                                    items: {
                                        type: Type.OBJECT,
                                        properties: {
                                            type: { type: Type.STRING, description: 'Type of element: narration, dialogue, or sound_cue.' },
                                            character: { type: Type.STRING, description: 'Character speaking (for dialogue type).' },
                                            content: { type: Type.STRING, description: 'The text of the narration or dialogue.' },
                                            description: { type: Type.STRING, description: 'Description of the sound (for sound_cue type).' }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    });
    
    const jsonString = response.text.trim();
    return JSON.parse(jsonString) as DramatizedScript;
};

export const generateFullAudio = async (
    script: DramatizedScript,
    voices: Record<string, string>,
    options: AudioOptions
): Promise<string> => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    const sceneAudioBuffers: AudioBuffer[] = [];

    for (const scene of script.scenes) {
        const sceneAudioBuffer = await generateSceneAudio(scene, voices, audioContext, options.generateSfx);
        if (sceneAudioBuffer) {
            sceneAudioBuffers.push(sceneAudioBuffer);
        }
    }

    if (sceneAudioBuffers.length === 0) {
        throw new Error("No audio could be generated for the script.");
    }
    
    let foregroundBuffer = stitchAudioBuffers(sceneAudioBuffers, audioContext);

    const musicUrl = BACKGROUND_MUSIC_TRACKS[options.musicTrackKey]?.url;
    if (musicUrl && options.musicVolume > 0) {
        try {
            const response = await fetch(musicUrl);
            const arrayBuffer = await response.arrayBuffer();
            // Use a new context for decoding music to handle different sample rates
            const musicDecodeContext = new (window.AudioContext || (window as any).webkitAudioContext)();
            const backgroundBufferRaw = await musicDecodeContext.decodeAudioData(arrayBuffer);
            
            // Resample background music to match foreground (24000 Hz) if necessary
            const backgroundBuffer = await resampleBuffer(backgroundBufferRaw, audioContext.sampleRate);

            foregroundBuffer = mixAudioBuffers(foregroundBuffer, backgroundBuffer, options.musicVolume);
            
            applyFade(foregroundBuffer, 2.0, true); 
            applyFade(foregroundBuffer, 3.0, false);

        } catch (e) {
            console.error("Failed to fetch or mix background music:", e);
        }
    }
    
    const wavBlob = bufferToWave(foregroundBuffer, foregroundBuffer.length);
    return URL.createObjectURL(wavBlob);
};

const generateSceneAudio = async (
    scene: Scene,
    voices: Record<string, string>,
    audioContext: AudioContext,
    generateSfx: boolean
): Promise<AudioBuffer | null> => {
    const elementBuffers: AudioBuffer[] = [];
    let speechChunk: (Dialogue | Narration)[] = [];

    const processSpeechChunk = async (chunk: (Dialogue | Narration)[]) => {
        if (chunk.length === 0) return;
        const buffer = await generateSpeechChunk(chunk, voices, audioContext);
        if (buffer) elementBuffers.push(buffer);
    };

    for (const element of scene.elements) {
        if (element.type === 'dialogue' || element.type === 'narration') {
            speechChunk.push(element);
        } else if (element.type === 'sound_cue' && generateSfx) {
            await processSpeechChunk(speechChunk);
            speechChunk = []; 
            const sfxBuffer = await generateSoundEffect(element.description, audioContext);
            if (sfxBuffer) elementBuffers.push(sfxBuffer);
        }
    }
    await processSpeechChunk(speechChunk);

    if (elementBuffers.length === 0) return null;
    return stitchAudioBuffers(elementBuffers, audioContext);
};

const generateSpeechChunk = async (
    elements: (Dialogue | Narration)[],
    voices: Record<string, string>,
    audioContext: AudioContext
): Promise<AudioBuffer | null> => {
    if (elements.length === 0) return null;

    const speakersInChunk = new Set<string>();
    let prompt = '';
    for (const element of elements) {
        const speaker = element.type === 'dialogue' ? element.character : 'Narrator';
        speakersInChunk.add(speaker);
        prompt += `${speaker}: ${element.content}\n`;
    }

    const speakerVoiceConfigs = Array.from(speakersInChunk).map(speaker => ({
        speaker: speaker,
        voiceConfig: { prebuiltVoiceConfig: { voiceName: voices[speaker] || 'Kore' } }
    }));
    
    if (speakerVoiceConfigs.length === 1) {
       speakerVoiceConfigs.push({
         speaker: 'PlaceholderSpeaker',
         voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } }
       });
    }
    if (speakerVoiceConfigs.length < 2) return null;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-tts',
        contents: [{ parts: [{ text: prompt }] }],
        config: {
            responseModalities: ['AUDIO'],
            speechConfig: { multiSpeakerVoiceConfig: { speakerVoiceConfigs } }
        }
    });
    
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
        const decodedBytes = decode(base64Audio);
        return await decodeAudioData(decodedBytes, audioContext, 24000, 1);
    }
    return null;
};

const generateSoundEffect = async (description: string, audioContext: AudioContext): Promise<AudioBuffer | null> => {
    const prompt = `[Sound of ${description}]`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-tts',
        contents: [{ parts: [{ text: prompt }] }],
        config: {
            responseModalities: ['AUDIO'],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } }
        }
    });
    
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
        const decodedBytes = decode(base64Audio);
        const sfxBuffer = await decodeAudioData(decodedBytes, audioContext, 24000, 1);
        const silenceBefore = audioContext.createBuffer(1, Math.floor(audioContext.sampleRate * 0.5), audioContext.sampleRate);
        const silenceAfter = audioContext.createBuffer(1, Math.floor(audioContext.sampleRate * 0.5), audioContext.sampleRate);
        return stitchAudioBuffers([silenceBefore, sfxBuffer, silenceAfter], audioContext);
    }
    return null;
};

async function resampleBuffer(audioBuffer: AudioBuffer, targetSampleRate: number): Promise<AudioBuffer> {
    if (audioBuffer.sampleRate === targetSampleRate) {
        return audioBuffer;
    }
    const duration = audioBuffer.duration;
    const offlineContext = new OfflineAudioContext(
        audioBuffer.numberOfChannels,
        duration * targetSampleRate,
        targetSampleRate
    );
    const bufferSource = offlineContext.createBufferSource();
    bufferSource.buffer = audioBuffer;
    bufferSource.connect(offlineContext.destination);
    bufferSource.start();
    return await offlineContext.startRendering();
}