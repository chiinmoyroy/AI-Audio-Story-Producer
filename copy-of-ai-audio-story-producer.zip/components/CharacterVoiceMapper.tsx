
import React from 'react';
import { AVAILABLE_VOICES } from '../constants';

interface CharacterVoiceMapperProps {
  characters: string[];
  characterVoices: Record<string, string>;
  onVoiceChange: (voices: Record<string, string>) => void;
  disabled: boolean;
}

const CharacterVoiceMapper: React.FC<CharacterVoiceMapperProps> = ({
  characters,
  characterVoices,
  onVoiceChange,
  disabled,
}) => {
  const handleVoiceChange = (character: string, voice: string) => {
    onVoiceChange({ ...characterVoices, [character]: voice });
  };

  return (
    <div className="space-y-4 p-4 bg-gray-900/50 border border-gray-700 rounded-lg">
      {characters.map((character) => (
        <div key={character} className="grid grid-cols-3 items-center gap-4">
          <label htmlFor={`voice-${character}`} className="text-gray-300 font-medium col-span-1">
            {character}
          </label>
          <select
            id={`voice-${character}`}
            value={characterVoices[character] || ''}
            onChange={(e) => handleVoiceChange(character, e.target.value)}
            disabled={disabled}
            className="col-span-2 w-full p-2 bg-gray-800 border border-gray-600 rounded-md focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors"
          >
            {AVAILABLE_VOICES.map((voice) => (
              <option key={voice} value={voice}>
                {voice}
              </option>
            ))}
          </select>
        </div>
      ))}
    </div>
  );
};

export default CharacterVoiceMapper;
