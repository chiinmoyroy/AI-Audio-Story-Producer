export function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export function stitchAudioBuffers(buffers: AudioBuffer[], context: AudioContext): AudioBuffer {
  const totalLength = buffers.reduce((acc, buffer) => acc + buffer.length, 0);
  const numChannels = buffers.length > 0 ? buffers[0].numberOfChannels : 1;
  const sampleRate = context.sampleRate;
  
  const outputBuffer = context.createBuffer(numChannels, totalLength, sampleRate);
  
  let offset = 0;
  for (const buffer of buffers) {
    for (let channel = 0; channel < numChannels; channel++) {
      outputBuffer.getChannelData(channel).set(buffer.getChannelData(channel), offset);
    }
    offset += buffer.length;
  }
  
  return outputBuffer;
}

export function applyFade(buffer: AudioBuffer, duration: number, fadeIn: boolean): AudioBuffer {
    const sampleRate = buffer.sampleRate;
    const length = buffer.length;
    const fadeLength = Math.min(Math.floor(duration * sampleRate), length);
    const numChannels = buffer.numberOfChannels;

    for (let channel = 0; channel < numChannels; channel++) {
        const channelData = buffer.getChannelData(channel);
        for (let i = 0; i < fadeLength; i++) {
            const sampleIndex = fadeIn ? i : length - fadeLength + i;
            if(sampleIndex < length) {
                const multiplier = fadeIn ? i / fadeLength : 1 - (i / fadeLength);
                channelData[sampleIndex] *= multiplier;
            }
        }
    }
    return buffer;
}

export function mixAudioBuffers(
    foreground: AudioBuffer,
    background: AudioBuffer,
    backgroundVolume: number
): AudioBuffer {
    if (background.length < foreground.length) {
        console.warn("Background music is shorter than the story audio.");
    }
    
    const context = new (window.AudioContext || (window as any).webkitAudioContext)();
    const mixedBuffer = context.createBuffer(
        foreground.numberOfChannels,
        foreground.length,
        foreground.sampleRate
    );

    for (let channel = 0; channel < foreground.numberOfChannels; channel++) {
        const foregroundData = foreground.getChannelData(channel);
        const backgroundData = background.numberOfChannels > channel ? background.getChannelData(channel) : background.getChannelData(0);
        const mixedData = mixedBuffer.getChannelData(channel);

        for (let i = 0; i < foreground.length; i++) {
            const bgSample = backgroundData[i] || 0;
            const fgSample = foregroundData[i];
            
            let mixedSample = fgSample + (bgSample * backgroundVolume);

            if (mixedSample > 1.0) mixedSample = 1.0;
            if (mixedSample < -1.0) mixedSample = -1.0;
            
            mixedData[i] = mixedSample;
        }
    }

    return mixedBuffer;
}


// Helper to convert an AudioBuffer to a WAV Blob
export function bufferToWave(abuffer: AudioBuffer, len: number): Blob {
    let numOfChan = abuffer.numberOfChannels,
        length = len * numOfChan * 2 + 44,
        buffer = new ArrayBuffer(length),
        view = new DataView(buffer),
        channels = [],
        i,
        sample,
        offset = 0,
        pos = 0;

    // write WAVE header
    setUint32(0x46464952); // "RIFF"
    setUint32(length - 8); // file length - 8
    setUint32(0x45564157); // "WAVE"

    setUint32(0x20746d66); // "fmt " chunk
    setUint32(16); // length = 16
    setUint16(1); // PCM (uncompressed)
    setUint16(numOfChan);
    setUint32(abuffer.sampleRate);
    setUint32(abuffer.sampleRate * 2 * numOfChan); // avg. bytes/sec
    setUint16(numOfChan * 2); // block-align
    setUint16(16); // 16-bit
    
    setUint32(0x61746164); // "data" - chunk
    setUint32(length - pos - 4); // chunk length

    // write interleaved data
    for (i = 0; i < abuffer.numberOfChannels; i++)
        channels.push(abuffer.getChannelData(i));

    while (pos < length) {
        for (i = 0; i < numOfChan; i++) {
            // interleave channels
            sample = Math.max(-1, Math.min(1, channels[i][offset])); // clamp
            sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0; // scale to 16-bit signed int
            view.setInt16(pos, sample, true); // write 16-bit sample
            pos += 2;
        }
        offset++; // next source sample
    }

    return new Blob([buffer], { type: "audio/wav" });

    function setUint16(data: number) {
        view.setUint16(pos, data, true);
        pos += 2;
    }

    function setUint32(data: number) {
        view.setUint32(pos, data, true);
        pos += 4;
    }
}